import 'package:assignment/screens/contact_page.dart';
import 'package:assignment/screens/gallery_page.dart';
import 'package:assignment/screens/main_page.dart';
import 'package:assignment/utils/colors.dart';
import 'package:assignment/utils/strings.dart';
import 'package:flutter/material.dart';

class SettingPage extends StatefulWidget {
  const SettingPage({Key? key}) : super(key: key);

  @override
  State<SettingPage> createState() => _SettingPageState();
}

class _SettingPageState extends State<SettingPage> {
  String link = 'https://krishworks.com/gallery/';
  int index = 0;
  Color bg = blue;
  Color txtbg = yellow;
  Color bg2 = white;
  Color txtbg2 = black;

  @override
  Widget build(BuildContext context) {
    double height = MediaQuery.of(context).size.height;

    return Scaffold(
      appBar: AppBar(
        backgroundColor: blue,
        leading: Center(
          child: TextButton(
              child: Text(close, style: TextStyle(color: white)),
              onPressed: () {
                Navigator.pushAndRemoveUntil(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MainPage(),
                    ),
                    (route) => false);
              }),
        ),
        title: Text(setting),
      ),
      body: Row(
        children: [
          Container(
            width: 150,
            height: height,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  color: bg,
                  width: 150,
                  height: 50,
                  child: TextButton(
                    onPressed: () {
                      index = 0;
                      bg = blue;
                      bg2 = white;
                      txtbg = yellow;
                      txtbg2 = black;
                      setState(() {});
                    },
                    child: Text(
                      gallery,
                      style: TextStyle(color: txtbg),
                    ),
                  ),
                ),
                Container(
                  color: bg2,
                  width: 150,
                  height: 50,
                  child: TextButton(
                    onPressed: () {
                      index = 1;
                      bg = white;
                      bg2 = blue;
                      txtbg = black;
                      txtbg2 = yellow;
                      setState(() {});
                    },
                    child: Text(
                      contact,
                      style: TextStyle(color: txtbg2),
                    ),
                  ),
                )
              ],
            ),
          ),
          Expanded(
            child: IndexedStack(
              index: index,
              children: [
                GalleryPage(),
                Contact_Page(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
