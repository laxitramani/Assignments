import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class GalleryPage extends StatefulWidget {
  const GalleryPage({Key? key}) : super(key: key);

  @override
  State<GalleryPage> createState() => _GalleryPageState();
}

class _GalleryPageState extends State<GalleryPage> {
  @override
  Widget build(BuildContext context) {
    return WebView(
      initialUrl: 'https://krishworks.com/gallery/',
    );
  }
}
