import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class Contact_Page extends StatefulWidget {
  const Contact_Page({Key? key}) : super(key: key);

  @override
  State<Contact_Page> createState() => _Contact_PageState();
}

class _Contact_PageState extends State<Contact_Page> {
  @override
  Widget build(BuildContext context) {
    return WebView(
      initialUrl: 'https://krishworks.com/contact /',
    );
  }
}
