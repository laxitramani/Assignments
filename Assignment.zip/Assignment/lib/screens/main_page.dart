import 'package:assignment/screens/about_page.dart';
import 'package:assignment/screens/home_page.dart';
import 'package:assignment/screens/setting_page.dart';
import 'package:assignment/screens/update_page.dart';
import 'package:assignment/utils/colors.dart';
import 'package:assignment/utils/icons.dart';
import 'package:assignment/utils/strings.dart';
import 'package:flutter/material.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  String currentText = '';
  DateTime date = DateTime.now();

  @override
  Widget build(BuildContext context) {
    String pass = (date.day * date.month * date.year).toString();
    if (pass.length == 5) {
      pass = '0$pass';
    }
    double width = MediaQuery.of(context).size.width;
    return DefaultTabController(
      initialIndex: 0,
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: black,
          centerTitle: true,
          leading: IconButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                    title: Center(child: Text(passcode)),
                    content: Container(
                      height: 70,
                      width: 400,
                      child: PinCodeTextField(
                        keyboardType: TextInputType.number,
                          appContext: context,
                          length: 6,
                          autoFocus: true,
                          pinTheme: PinTheme(
                            shape: PinCodeFieldShape.box,
                            selectedColor: black,
                            activeColor: black,
                            inactiveColor: black,
                            disabledColor: black,
                            borderRadius: BorderRadius.circular(5),
                            fieldHeight: 50,
                            fieldWidth: 40,
                          ),
                          onChanged: (value) {
                            setState(() {
                              currentText = value;

                              if (pass == currentText) {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => SettingPage(),
                                  ),
                                );
                              }
                            });
                          }),
                    ),
                  ),
                );
              },
              icon: Icon(icsetting)),
          title: Container(
            width: width * 0.6,
            decoration: BoxDecoration(
              color: blue,
              borderRadius: BorderRadius.circular(10),
            ),
            child: TabBar(
              indicator: BoxDecoration(
                borderRadius: BorderRadius.circular(10), // Creates border
                color: white,
              ),
              unselectedLabelColor: white,
              labelColor: blue,
              tabs: [
                Tab(
                  child: Text(home),
                ),
                Tab(
                  child: Text(about),
                ),
                Tab(
                  child: Text(update),
                ),
              ],
            ),
          ),
        ),
        body: const TabBarView(
          children: [
            HomePage(),
            AboutPage(),
            UpdatePage(),
          ],
        ),
      ),
    );
  }
}
