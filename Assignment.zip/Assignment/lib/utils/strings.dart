const String home  = 'Home';
const String about  = 'About us';
const String update  = 'Update';
const String passcode  = 'Developer Passcode';
const String close = 'Close';
const String setting = 'Setting';
const String gallery  = 'Gallery';
const String contact  = 'Contact Us';