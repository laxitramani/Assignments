import 'package:flutter/material.dart';

const Color yellow = Color(0xffffad33);
const Color black = Color(0xff002633);
const Color white = Color(0xffffffff);
const Color blue = Color(0xff015574);