import 'package:flutter/material.dart';

IconData icsetting = Icons.settings;